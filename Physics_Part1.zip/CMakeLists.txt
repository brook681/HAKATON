cmake_minimum_required(VERSION 3.20)

project(ThreeBodyPhysics LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

add_library(physics
    src/physics/Physics.cpp
    src/physics/Scenarios.cpp
)

target_include_directories(physics PUBLIC
    ${CMAKE_CURRENT_SOURCE_DIR}/src/physics
)

add_executable(physics_tests
    tests/physics_tests.cpp
)

target_link_libraries(physics_tests PRIVATE physics)

if(MSVC)
    target_compile_options(physics PRIVATE /W4)
    target_compile_options(physics_tests PRIVATE /W4)
else()
    target_compile_options(physics PRIVATE -Wall -Wextra -Wpedantic)
    target_compile_options(physics_tests PRIVATE -Wall -Wextra -Wpedantic)
endif()
